const { Service } = require("moleculer");
const ApiGateway = require("moleculer-web");

class APIService extends Service {
  constructor(broker) {
    super(broker);
    this.parseServiceSchema({
      name: "api",
      mixins: [ApiGateway],
      settings: {
        port: process.env.PORT || 3333,
        routes: [
          {
            path: "/api/user",
            aliases: {
              "POST /login": "auth.login",
              "POST /register": "auth.register"
            },
            mappingPolicy: "restrict",
            authorization: false,
            cors: false,
            bodyParsers: {
              json: true,
              urlencoded: {
                extended: true
              },
              text: { type: "text/plain" },
              raw: true
            }
          },
          {
            path: "/api",
            aliases: {
              "GET /products": "product.getProducts",
              "GET /cart": "cart.getCart",
              "POST /cart": "cart.addToCart"
            },
            mappingPolicy: "restrict",
            authorization: true,
            cors: false,
            bodyParsers: {
              json: true,
              urlencoded: {
                extended: true
              },
              text: { type: "text/plain" },
              raw: true
            }
          }
        ]
      },
      methods: {
        async authorize(ctx, route, req, res) {
          let auth = req.headers["authorization"];
          if (auth && auth.startsWith("Bearer")) {
            let authToken = auth.slice(7);
            let token = await ctx.call("auth.verifyToken", {
              authToken: authToken
            });
            if (token.userId) {
              ctx.meta.userId = token.userId;
              return Promise.resolve(ctx);
            } else {
              return Promise.reject(
                new ApiGateway.Errors.UnAuthorizedError(
                  ApiGateway.Errors.ERR_INVALID_TOKEN
                )
              );
            }
          } else {
            return Promise.reject(
              new ApiGateway.Errors.UnAuthorizedError(
                ApiGateway.Errors.ERR_NO_TOKEN
              )
            );
          }
        }
      },
      onError(req, res, err) {
        res.setHeader("Content-Type", "text/plain");
        res.writeHead(500);
        res.end(err.message);
      }
    });
  }
}

module.exports = APIService;
