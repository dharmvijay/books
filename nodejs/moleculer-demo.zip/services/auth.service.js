const { Service } = require("moleculer");
const ES = require("../mixins/elasticSearch.mixin");
const ErrorHelper = require("../mixins/error.mixin");
const apiResponse = require("../mixins/apiResponse.mixin");
const jwt = require("jsonwebtoken");

class AuthService extends Service {
  constructor(broker) {
    super(broker);
    const salt = "Have a nice day.";

    this.parseServiceSchema({
      name: "auth",
      mixins: [ES, ErrorHelper, apiResponse],
      actions: {
        /**
         * get user by email if it exist then match password
         * if user with email does not exist then throw error
         * if user with email and password exist then generate jwt token and return in response.
         */

        login: {
          params: {
            email: { type: "string" },
            password: { type: "string" }
          },
          handler(ctx) {
            return ctx
              .call("user.getUserByEmail", { email: ctx.params.email })
              .then(async userRes => {
                if (userRes.hits.hits.length > 0) {
                  const userData = userRes.hits.hits[0]._source;
                  if (userData.password == ctx.params.password) {
                    const authToken = await jwt.sign(
                      { userId: userData.userId },
                      salt
                    );
                    return this.success(
                      { auth_token: authToken },
                      "Auth token generated successfully."
                    );
                  } else {
					this.throwInvalidRequestError(
						"Invalid Email password."
					  );	
				  }
                } else {
                  this.throwInvalidRequestError(
                    "Invalid Email password."
                  );
                }
              }).catch(error => {
				this.throwInternalError(error);
			  });
          }
        },
        /**
         * Check user with same email id exist
         * Throw error and say please try again with different email id
         * If email does not exist then create new user by calling create user service.
         */
        register: {
          params: {
            name: { type: "string" },
            email: { type: "string" },
            userId: { type: "number" },
            password: { type: "string" }
          },
          handler(ctx) {
            return ctx
              .call("user.getUserByEmail", { email: ctx.params.email })
              .then(userData => {
                if (userData.hits.hits.length > 0) {
					console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", userData.hits.hits)
                  this.throwInvalidRequestError(
                    "Email id already in use.Please try with another."
                  );
                } else {
                  return ctx.call("user.createUser", ctx.params);
                }
              }).catch(error => {
				this.throwInternalError(error);
			  });
          }
        },
        verifyToken: {
          params: {
            authToken: { type: "string" }
          },
          handler(ctx) {
            return jwt.verify(ctx.params.authToken, salt);
          }
        }
      }
    });
  }
}

module.exports = AuthService;
