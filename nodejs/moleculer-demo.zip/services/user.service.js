const { Service } = require("moleculer");
const ES = require("../mixins/elasticSearch.mixin");
const ErrorHelper = require("../mixins/error.mixin");
const apiResponse = require("../mixins/apiResponse.mixin");

class UserService extends Service {
  constructor(broker) {
    super(broker);

    this.parseServiceSchema({
      name: "user",
      mixins: [ES, ErrorHelper, apiResponse],
      actions: {
        createUser: {
          params: {
            name: { type: "string" },
            email: { type: "string" },
            userId: { type: "number" },
            password: { type: "string" }
          },
          handler(ctx) {
            return this.Promise.resolve()
              .then(() => {
                //TODO: encrypt password using bcrypt.
                return this.addUser(
                  ctx.params.email,
                  ctx.params.name,
                  ctx.params.password,
                  ctx.params.userId
                );
              })
              .then(() => {
                return this.success({}, "User added successfully.");
              })
              .catch(error => {
                this.throwInternalError(error);
              });
          }
        },
        getUserByEmail: {
          params: {
            email: { type: "string" }
          },
          handler(ctx) {
            return this.Promise.resolve()
              .then(() => {
                return this.getUserByEmail(ctx.params.email);
              })
              .catch(error => {
                this.throwInternalError(error);
              });
          }
        }
      },
      started() {
        this.isUserIndexExist()
          .then(async isUserIndexExist => {
            if (!isUserIndexExist) {
              await this.createUserIndex();
              const ud = await this.addTestUserData();
              this.logger.info(">>> User seeded", ud);
            }
          })
          .catch(error => {
            this.logger.error(">>> User seed error", error);
          });
      }
    });
  }
}

module.exports = UserService;
