const { Service } = require("moleculer");
const ES = require("../mixins/elasticSearch.mixin");
const ErrorHelper = require("../mixins/error.mixin");
const apiResponse = require("../mixins/apiResponse.mixin");
const _ = require('lodash');

class CartService extends Service {
  constructor(broker) {
    super(broker);
    this.parseServiceSchema({
      name: "cart",
      mixins: [ES, ErrorHelper, apiResponse],
      actions: {
        getCart: {
          async handler(ctx) {
			const userId = ctx.meta.userId;
			console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>userId",userId)

            return this.getCartByUserId(userId)
              .then(cartProducts => {
                const cartDetails = [];
                for (const cartProduct of cartProducts.hits.hits) {
                  cartDetails.push({
                    id: cartProduct._id,
                    ...cartProduct._source
                  });
                }
                return this.success(
                  cartDetails,
                  "Cart retrieved successfully."
                );
              })
              .catch(error => {
                this.throwInternalError(error);
              });
          }
        },
        addToCart: {
          //add product to existing cart if product not exist
          //update quantity only if product in cart exist
          params: {
            productId: { type: "number" },
            quantity: { type: "number" }
          },
          async handler(ctx) {
			const userId = ctx.meta.userId;
			console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>userId",userId)
            return this.getCartByUserId(userId)
              .then(cartRes => {
                const cartDetails = cartRes.hits.hits;
				const { productId, quantity } = ctx.params;
				console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>cartDetails",cartDetails)
				
                if (cartDetails.length > 0) {
					console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>productId",productId)
					console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>quantity",quantity)
				
				  const dbProduct = cartDetails[0]._source.product;


				  dbProduct.forEach(element => {
                    if (element.productId == productId) {
                      element.quantity = element.quantity + quantity;
                    } else {
					  dbProduct.push({ productId, quantity });
					}
				  });

				  console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>dbProduct",dbProduct);



                //   const products = cartDetails[0]._source.product;
                //   let updateProductData = [];
                //   products.forEach(element => {
                //     if (element.productId == productId) {
                //       element.quantity = element.quantity + quantity;
                //       updateProductData.push(element);
                //     } else {
                //       updateProductData.push({ productId, quantity });
				// 	}
				// 	console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>element",element)

				//   });
				//   console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>updateProductData",updateProductData)

                  return this.updateQuantity(
                    userId,
                    cartDetails[0]._id,
                    updateProductData
                  ).then(() =>
                    this.success({}, "Product added to cart successfully.")
                  );
                } else {
                  return this.addProductToCart(
                    userId,
                    productId,
                    quantity
                  ).then(() =>
                    this.success({}, "Product added to cart successfully.")
                  );
                }
              })
              .catch(error => {
                this.throwInternalError(error);
              });
          }
        }
      },
      started() {
        this.isCartIndexExist()
          .then(async isCartIndexExist => {
            if (!isCartIndexExist) {
              await this.createCartIndex();
              const ud = await this.addTestCartData();
              this.logger.info(">>> Cart seeded", ud);
            }
          })
          .catch(error => {
            this.logger.error(">>> Cart seed error", error);
          });
      }
    });
  }
}

module.exports = CartService;
