"use strict";

const { ServiceBroker } = require("moleculer");
const AuthService = require("../../services/auth.service");
const jwt = require("jsonwebtoken");

describe("Test 'auth' service", () => {
	let broker = new ServiceBroker({ logger: false });
	let randomNumber = Math.floor(Math.random() * 90 + 10);
	broker.createService(AuthService);

	beforeAll(() => broker.start());
	afterAll(() => broker.stop());

	describe("Test 'auth.verifyToken' action", () => {
		it("should return user id 1", async () => {
			const salt = "Have a nice day.";
			const authToken = await jwt.sign({ userId: 1 },salt);

			broker.call("auth.verifyToken", {authToken : authToken}).then(response => {
				expect(response.userId).toEqual(1);
			});
		});
	});
	
	describe("Test 'auth.register' action", () => {
		it("should return success true", async () => {
			await broker.call("auth.register", {
				userId: randomNumber,
				name: "test"+randomNumber,
				email: "test@example.com"+randomNumber,
				password: "123456"
			}).then(response => {
				expect(response.success).toEqual(true);
			});
		});
	});

	describe("Test 'auth.login' action", () => {
		it("should return success true with auth_token", async () => {
			await broker.call("auth.login", {
				email: "test@example.com"+randomNumber,
				password: "123456"
			}).then(response => {
				expect(response.success).toEqual(true);
			});
		});

		it("should return success false with internal server error", async () => {
			await broker.call("auth.login", {
				email: "123123",
				password: "123456"
			}).catch(response => {
				expect(response.code).toEqual(500);
			});
		});
	});

});

