"use strict";

const { ServiceBroker } = require("moleculer");
const ProductService = require("../../services/product.service");

describe("Test 'product' service", () => {
	let broker = new ServiceBroker({ logger: false });
	broker.createService(ProductService);

	beforeAll(() => broker.start());
	afterAll(() => broker.stop());

	describe("Test 'product.started' action", () => {
		it("should return with 'success: true'", () => {
			expect(broker.start("product.started")).resolves.toBeUndefined();
		});
	});

	describe("Test 'product.getProducts' action", () => {
		it("should return with 'success: true'", async () => {
			const getProductRes = await broker.call("product.getProducts", {});
		 	expect(Promise.resolve(getProductRes)).resolves.toMatchObject({"success": true});;
		});
		it("should return with 'success: false'", async () => {
			broker.call("product.getProducts", {}).catch(err => {
				expect(err.code).toEqual(500);
			});
		});
	});


});

