const elasticsearch = require("elasticsearch");

const esHost = process.env.ELASTIC_HOST;
const esLog = process.env.ELASTIC_LOG;
const esVersion = process.env.ELASTIC_VERSION;
const esClient = new elasticsearch.Client({
  host: esHost,
  log: esLog,
  apiVersion: esVersion
});
const index = {
  products: "products",
  users: "users",
  cart: "cart"
};

module.exports = {
  methods: {
    esClient() {
      return esClient;
    },
    getProductData() {
      return esClient.search({
        index: index.products,
        body: { query: { match_all: {} } }
      });
    },
    addProductToCart(userId, productId, quantity) {
      return esClient.index({
        index: index.cart,
        body: {
          cartId: userId,
          product: [
            {
              productId: productId,
              quantity: quantity
            }
          ],
          userId: userId
        }
      });
    },
    updateQuantity(userId, docId, updateProductData) {
      return esClient.update({
        index: index.cart,
        id: docId,
        body: {
          doc: {
            cartId: userId,
            product: updateProductData,
            userId: userId
          }
        }
      });
    },
    getCartByUserId(userId) {
      return esClient.search({
        index: index.cart,
        body: {
          query: {
            match_phrase: {
              userId: userId
            }
          }
        }
      });
    },
    getUserByEmail(email) {
      return esClient.search({
        index: index.users,
        body: {
          query: {
            match_phrase: {
              email: email
            }
          }
        }
      });
    },
    addUser(email, name, password, userId) {
      return esClient.index({
        index: index.users,
        body: {
          name: name,
          email: email,
          password: password,
          userId: userId
        }
      });
    },
    isUserIndexExist() {
      return esClient.indices.exists({
        index: index.users,
        body: {}
      });
    },
    createUserIndex() {
      return esClient.indices.create({
        index: index.users,
        body: {
          mappings: {
            _doc: {
              properties: {
                name: { type: "text" },
                email: { type: "text" },
                userId: { type: "integer" },
                password: { type: "text" }
              }
            }
          }
        }
      });
    },
    addTestUserData() {
      const user = {
        id: 1,
        name: "test user",
        email: "test@example.com",
        password: "123456"
      };
      return this.addUser(user.email, user.name, user.password, user.id);
    },
    isCartIndexExist() {
      return esClient.indices.exists({
        index: index.cart,
        body: {}
      });
    },
    createCartIndex() {
      return esClient.indices.create({
        index: index.cart,
        body: {
          mappings: {
            _doc: {
              properties: {
                cartId: { type: "integer" },
                product: {
                  properties: {
                    productId: {
                      type: "integer"
                    },
                    quantity: {
                      type: "integer"
                    }
                  }
                },
                userId: { type: "integer" },
                password: { type: "text" }
              }
            }
          }
        }
      });
    },
    addTestCartData() {
      const cart = {
        id: 1,
        productId: 1,
        quantity: 1
      };
      return this.addProductToCart(cart.id, cart.productId, cart.quantity);
    },
    isProductIndexExist() {
      return esClient.indices.exists({
        index: index.products,
        body: {}
      });
    },
    createProductsIndex() {
      return esClient.indices.create({
        index: index.products,
        body: {
          mappings: {
            _doc: {
              properties: {
                name: { type: "text" },
                productId: { type: "integer" },
                price: { type: "integer" }
              }
            }
          }
        }
      });
    },
    addTestProducts(price, name, productId) {
      return esClient.index({
        index: index.products,
        body: {
          name: name,
          price: price,
          productId: productId
        }
      });
    },
    addTestProductsData() {
      const product = {
        name: "My test product",
        id: 1,
        price: 123
      };
      return this.addTestProducts(product.price, product.name, product.id);
    }
  }
};
