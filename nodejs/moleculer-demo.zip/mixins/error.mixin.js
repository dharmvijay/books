const {
  MoleculerClientError,
  ServiceNotFoundError,
  ValidationError,
  RequestRejectedError
} = require("moleculer").Errors;

module.exports = {
  methods: {
    throwInternalError(err) {
      this.logger.error(">> err : ", err);
      throw new MoleculerClientError("Internal server error!", 500, "", [
        {
          success: "false",
          message: "Internal server error! Please try after sometime",
          payload: null
        }
      ]);
    },
    throwNotFoundError(err) {
      this.logger.error(">> err : ", err);
      throw new ServiceNotFoundError("Resource not found.", 404, "", [
        {
          success: "false",
          message: "Resource not found.",
          payload: null
        }
      ]);
    },
    throwValidationError(message) {
      this.logger.error(">> err : ", message);
      throw new ValidationError("Validation error.", 422, "", [
        {
          success: "false",
          message: message,
          payload: null
        }
      ]);
    },
    throwInvalidRequestError(message) {
      this.logger.error(">> err : ", message);
      throw new RequestRejectedError(message, 422, "", [
        {
          success: "false",
          message: message,
          payload: null
        }
      ]);
    }
  }
};
