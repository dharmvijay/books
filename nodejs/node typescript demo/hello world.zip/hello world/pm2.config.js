module.exports = {
  apps: [
    {
      name: 'mentavio.cms',
      script: './build/app.js',
      autorestart: true
    }
  ]
};
