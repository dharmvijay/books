$(() => {
  $('#editPermissionForm,#createPermissionForm').validate({
    rules: {
      name: {
        required: true
      },
      status: {
        required: true
      },
      description: {
        required: true
      }
    },
    messages: {
      name: {
        required: 'NAME is required!'
      },
      status: {
        required: 'STATUS is required!'
      },
      description: {
        required: 'DESCRIPTION is required!'
      }
    },
    errorElement: 'span',
    errorLabelContainer: '.error',
    submitHandler: form => {
      form.submit();
    }
  });
});

$(() => {
  const permissions = $('#permissions').val();
  if (typeof $('#permissionList').dataTable == 'function') {
    $('#permissionList').dataTable({
      processing: true,
      serverSide: true,
      ajax: '/admin/permission/list',
      columns: [
        { data: 'description' },
        {
          data: 'status',
          searchable: false,
          sortable: false,
          render(status, type, full, meta) {
            return status == 1 ? 'On' : 'Off';
          }
        },
        {
          data: 'id',
          searchable: false,
          sortable: false,
          render(id, type, full, meta) {
            let links = '';
            if (permissions && permissions.includes('edit_permission')) {
              links = `<a href="/admin/permission/${id}">
                          <i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i>
                        </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`;
            }
            if (permissions && permissions.includes('delete_permission')) {
              links += `<a href="/admin/permission/${id}/delete">
                          <i class="fa fa-trash" data-toggle="tooltip" title="Delete"></i>
                        </a>`;
            }
            return links;
          }
        }
      ]
    });
  }
});
