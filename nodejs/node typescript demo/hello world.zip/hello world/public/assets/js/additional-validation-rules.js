$.validator.addMethod('regx', (value, element, regexpr) => regexpr.test(value), 'Please enter a error message!');

