$(() => {
  $('#currencyForm').validate({
    rules: {
      code: {
        required: true
      },
      symbol: {
        required: true
      }
    },
    messages: {
      code: {
        required: 'CURRENCY code is required!'
      },
      symbol: {
        required: 'CURRENCY symbol is required!'
      }
    },
    errorElement: 'span',
    errorLabelContainer: '.error',
    submitHandler: form => {
      form.submit();
    }
  });
});

$(() => {
  const permissions = $('#permissions').val();
  if (typeof $('#currencyList').dataTable == 'function') {
    $('#currencyList').dataTable({
      processing: true,
      serverSide: true,
      ajax: '/admin/currency/list',
      columns: [
        { data: 'code' },
        { data: 'symbol' },
        {
          data: 'id',
          searchable: false,
          sortable: false,
          render: function(id, type, full, meta) {
            let links = '';
            if (permissions && permissions.includes('edit_currency')) {
              links = `<a href="/admin/currency/${id}"><i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i></a> &nbsp;&nbsp;&nbsp;&nbsp;`;
            }
            if (permissions && permissions.includes('delete_currency')) {
              links += `<a href="/admin/currency/${id}/delete"><i class="fa fa-trash" data-toggle="tooltip" title="Delete"></i></a>`;
            }
            return links;
          }
        }
      ]
    });
  }
});
