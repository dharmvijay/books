$(() => {
  $('#editRoleForm,#createRoleForm').validate({
    rules: {
      name: {
        required: true
      },
      status: {
        required: true
      }
    },
    messages: {
      name: {
        required: 'NAME is required!'
      },
      status: {
        required: 'STATUS is required!'
      }
    },
    errorElement: 'span',
    errorLabelContainer: '.error',
    submitHandler: form => {
      form.submit();
    }
  });
});

$(() => {
  const permissions = $('#permissions').val();
  if (typeof $('#roleList').dataTable === 'function') {
    $('#roleList').dataTable({
      processing: true,
      serverSide: true,
      ajax: '/admin/role/list',
      columns: [
        { data: 'name' },
        {
          data: 'status',
          searchable: false,
          sortable: false,
          render(status, type, full, meta) {
            return status == 1 ? 'On' : 'Off';
          }
        },
        {
          data: 'id',
          searchable: false,
          sortable: false,
          render(id, type, full, meta) {
            let links = '';
            if (permissions && permissions.includes('edit_role')) {
              links = `<a href="/admin/role/${id}">
                          <i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i>
                      </a>&nbsp&nbsp&nbsp&nbsp&nbsp`;
            }
            if (permissions && permissions.includes('delete_role')) {
              links += `<a href="/admin/role/${id}/delete"><i class="fa fa-trash" data-toggle="tooltip" title="Delete"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp`;
            }
            if (permissions && permissions.includes('assign_permissions')) {
              links += `<a href="/admin/role/${id}/permission/assign"><img src="../../images/key.svg" class="svg"  data-toggle="tooltip" title="Assign Permission" alt="Assign Permission"></a>`;
            }
            return links;
          }
        }
      ]
    });
  }
});
