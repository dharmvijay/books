$(document).ready(() => {
  $('#userForm').validate({
    rules: {
      first_name: {
        required: true
      },
      last_name: {
        required: true
      },
      email: {
        required: true,
        email: true
      },
      password: {
        required: true
      },
      role: {
        required: true
      }
    },
    messages: {
      first_name: {
        required: 'FIRST MAME is required!',
      },
      last_name: {
        required: 'LAST MAME is required!',
      },
      email: {
        required: 'EMAIL is required!',
        email: 'Please enter valid EMAIL address!'
      },
      password: {
        required: 'PASSWORD is required!',
      },
      role: {
        required: 'Role is required!',
      }
    },
    errorElement: 'span',
    errorLabelContainer: '.error',
    submitHandler: (form) => {
      form.submit();
    }
  })
});